#ifndef UTILS_H
#define UTILS_H

void printDigit(float *data, int gridSide);
void shuffle(int *array, int n);

#endif // UTILS_H