#ifndef UTILS_H
#define UTILS_H

void printDigit(const float *data, const int gridSide);
void shuffle(int *array, int n);

#endif // UTILS_H