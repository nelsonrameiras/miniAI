#ifndef _MEMORY_DATASETS_H
#define _MEMORY_DATASETS_H

extern float dataset[62][64];
extern float digits[10][25];

#endif // _MEMORY_DATASETS_H